package Book;

public class ShowcaseBook extends Book {
    public ShowcaseBook(String ISBN, String title, int year, double price) {
        super(ISBN, title, year, price);
    }

    @Override
    public String getType() {
        return "ShowcaseBook";
    }

    @Override
    public boolean isForSale() {
        return false;
    }
}