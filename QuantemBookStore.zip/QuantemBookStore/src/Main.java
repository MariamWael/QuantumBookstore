import Book.*;
import Service.*;
import java.util.List;

public class Main {
    public static void main(String[] args) {
        BookStoreService store = new BookStoreService();

        // Load initial inventory from CSV
        store.loadInventoryFromCSV("books.csv");

        // Add a new book and save back to CSV
        store.addBook(new PaperBook("ISBN111", "Data Structures", 2020, 120.0, 10));
        store.saveInventoryToCSV("books.csv");

        // Test buying, removing, etc. as before
        try {
            double paid = store.buyBook("ISBN123", 2, "user@mail.com", "123 Street");
            System.out.println("Purchased PaperBook, paid: " + paid);
        } catch (Exception e) {
            System.out.println(e.getMessage());
        }

        // Remove outdated books and save
        List<Book> removed = store.removeOutdatedBooks(1950);
        for (Book b : removed) {
            System.out.println("Removed outdated book: " + b.getTitle());
        }
        store.saveInventoryToCSV("books.csv");
    }
}