package Service;

public class ShippingService {
    public static void sendPaperBook(String address, String bookTitle) {
        System.out.println("Shipping paper book '" + bookTitle + "' to " + address);
        // No actual implementation
    }
}