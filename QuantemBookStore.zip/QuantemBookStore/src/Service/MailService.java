package Service;

public class MailService {
    public static void sendEBook(String email, String bookTitle) {
        System.out.println("Sending ebook '" + bookTitle + "' to " + email);
        // No actual implementation
    }
}
