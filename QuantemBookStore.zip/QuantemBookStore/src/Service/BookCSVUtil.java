package Service;

import Book.*;
import java.io.*;
import java.util.*;

public class BookCSVUtil {

    public static List<Book> loadBooks(String filename) {
        List<Book> books = new ArrayList<>();
        try (BufferedReader br = new BufferedReader(new FileReader(filename))) {
            String header = br.readLine(); // skip header
            String line;
            while ((line = br.readLine()) != null) {
                String[] fields = line.split(",");
                String ISBN = fields[0];
                String title = fields[1];
                int year = Integer.parseInt(fields[2]);
                double price = Double.parseDouble(fields[3]);
                String type = fields[4];

                if ("PaperBook".equalsIgnoreCase(type)) {
                    int stock = Integer.parseInt(fields[5]);
                    books.add(new PaperBook(ISBN, title, year, price, stock));
                } else if ("EBook".equalsIgnoreCase(type)) {
                    String fileType = fields.length > 6 ? fields[6] : "PDF";
                    books.add(new EBook(ISBN, title, year, price, fileType));
                } else if ("ShowcaseBook".equalsIgnoreCase(type)) {
                    books.add(new ShowcaseBook(ISBN, title, year, price));
                }
            }
        } catch (Exception e) {
            System.out.println("Error loading books: " + e.getMessage());
        }
        return books;
    }

    public static void saveBooks(String filename, Collection<Book> books) {
        try (PrintWriter pw = new PrintWriter(new FileWriter(filename))) {
            pw.println("ISBN,Title,Year,Price,Type,Stock,FileType");
            for (Book book : books) {
                if (book instanceof PaperBook) {
                    PaperBook pb = (PaperBook) book;
                    pw.printf("%s,%s,%d,%.2f,%s,%d,%n",
                            pb.getISBN(), pb.getTitle(), pb.getYear(), pb.getPrice(), pb.getType(), pb.getStock()
                    );
                } else if (book instanceof EBook) {
                    EBook eb = (EBook) book;
                    pw.printf("%s,%s,%d,%.2f,%s,,%s%n",
                            eb.getISBN(), eb.getTitle(), eb.getYear(), eb.getPrice(), eb.getType(), eb.getFileType()
                    );
                } else if (book instanceof ShowcaseBook) {
                    pw.printf("%s,%s,%d,%.2f,%s,,%n",
                            book.getISBN(), book.getTitle(), book.getYear(), book.getPrice(), book.getType()
                    );
                }
            }
        } catch (Exception e) {
            System.out.println("Error saving books: " + e.getMessage());
        }
    }
}