package Service;

import Book.*;
import java.util.*;
import java.util.stream.Collectors;

public class BookStoreService {
    private Map<String, Book> inventory = new HashMap<>();

    public void loadInventoryFromCSV(String filename) {
        List<Book> books = BookCSVUtil.loadBooks(filename);
        for (Book b : books) {
            inventory.put(b.getISBN(), b);
        }
    }

    public void saveInventoryToCSV(String filename) {
        BookCSVUtil.saveBooks(filename, inventory.values());
    }

    public void addBook(Book book) {
        inventory.put(book.getISBN(), book);
    }

    public List<Book> removeOutdatedBooks(int cutoffYear) {
        List<Book> removed = inventory.values().stream()
                .filter(book -> book.getYear() < cutoffYear)
                .collect(Collectors.toList());
        for (Book book : removed) {
            inventory.remove(book.getISBN());
        }
        return removed;
    }

    public double buyBook(String ISBN, int quantity, String email, String address) throws Exception {
        Book book = inventory.get(ISBN);
        if (book == null || !book.isForSale()) {
            throw new Exception("Book not available for sale");
        }

        if (book instanceof PaperBook) {
            PaperBook pb = (PaperBook) book;
            if (pb.getStock() < quantity) throw new Exception("Not enough stock");
            pb.reduceStock(quantity);
            ShippingService.sendPaperBook(address, pb.getTitle());
        } else if (book instanceof EBook) {
            MailService.sendEBook(email, book.getTitle());
        } else {
            throw new Exception("Book type not supported for buying");
        }
        return book.getPrice() * quantity;
    }

    public Book getBook(String ISBN) {
        return inventory.get(ISBN);
    }

    public Map<String, Book> getInventory() {
        return inventory;
    }
}